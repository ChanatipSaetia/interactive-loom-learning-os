## Focused component contracts

Page rules: root = Page("Title", body, heading?). One section file is one authored page; choose components, not a section type or library. Use one main visual/activity plus supporting text. Local controls and their visual form one activity. Multiple competing activities produce review warnings, not a component-count rejection. Size the topic to the learner goal. Generic children are alternatives, not mandatory dependencies. Use exact positional signatures; request actual child components and required data models. TextContent handles Markdown prose; Text is a short line or metric. Choose ImageGallery for a preview grid or LearningGallery for captioned learning scenes. All components share one catalog; prebuilt activities are reusable compositions, not a separate authoring mode. Query/Mutation host tools are deferred. Local reactive $variables, input bindings and Set/Reset actions are allowed. Do not use actions unsupported by the host. Include useful learner-visible reference links for deeper reading, with descriptive labels and supplied or checked destinations; keep the core lesson self-contained. See contracts/learner-references.md (installed skills: references/core/learner-references.md). Before adding image sources, read contracts/images.md and runtime.md (installed skills: references/core/images.md); a reachable HTTPS URL may still be blocked by the MCP host. Use supplied/verified chart data or label illustrative values; never invent benchmarks. Present is hands-free, may use internal scenes/beats, and may render differently from Read using the same content. Demonstrations use authored defaults and never count as learner attempts. Narration is authored in OUI; preserve statement IDs and validate beat/target references. Preview narrow and desktop Read/Present layouts.

## Component Signatures

GalleryImage(id: string, url: string, caption: string, credit?: string) — An image in a gallery.
  - id: Image ID, unique within the gallery.
  - url: Image URL or path.
  - caption: Caption shown under the image.
  - credit: Optional attribution.

### GalleryImage: teaching purpose

- Introduce: Define the GalleryImage content or configuration consumed by its owning component.
- Explore: Inspect it through the owning component and its documented behavior.
- Evidence: A supporting data declaration does not independently provide learning evidence.
- Limits: Use the exact required fields and references. This supporting contract does not imply an independently rendered activity, interaction, grading or persistence.

### Images in the MCP player

Choose images that teach recognition, a concrete example or a relevant feature. Use the selected component's exact fields, descriptive alt text where supported, and useful captions or credits. Do not invent URLs, image content, or accessibility/attribution properties absent from the contract. Encourage a learner-visible source/credit/detail link in supported content or adjacent TextContent, separate from the direct image source. LearningGallery credit/caption strings are plain text, so place clickable references in adjacent TextContent; see contracts/learner-references.md (installed skills: references/core/learner-references.md).

Before choosing a source for MCP, read runtime.md through read_reference and inspect deployment.imagePolicy. Its resourceDomains are the server's requested CSP allowlist for images and other static resources; connectDomains govern fetch/XHR, not ordinary image elements. A publicly reachable HTTPS URL is not sufficient when its origin is not permitted. The chat host enforces the final policy and may impose further restrictions. If metadata is unavailable, treat image delivery as unverified rather than assuming permission.

With the default hosted configuration, the declared origins are the app asset origin and font origins; an arbitrary image CDN is not declared. Use an existing, verified image at an allowed origin, including redirect destinations. Check expiry, authentication and provider hotlink restrictions; origin permission does not override them. Font origins are listed for fonts, not offered as an image library. The bundled local app explicitly declares data: resources and no remote origins. The hosted configuration does not explicitly declare data:; do not promise data URLs will work there without checking the actual host. A custom appUrl changes the asset origin; inspect the current metadata instead of assuming a fixed domain.

An image source must be a direct, browser-loadable image response, not a search-result page, Drive preview, login page, chat attachment ID or temporary workspace path. Relative paths, file://, sandbox paths and blob URLs from another app/session are not portable image delivery. Do not assume a learner's authenticated connector session or local topic folder is available inside the iframe. Current topic import/export carries OUI files, not an uploaded image-asset bundle; Loom exposes no image upload/publishing tool that creates a public URL.

A small raster data URL can be used only where the host permits it. Base64 adds roughly one third to the binary size; the complete new-topic source review is limited to 262144 JavaScript characters, including embedded data. This is a topic-source limit, not an image-byte limit; clients and tool transports may have additional payload limits. Prefer appropriately compressed images and avoid large inline payloads. Do not claim a universal image dimension, format or byte limit that the player has not implemented.

When a self-contained conceptual illustration teaches the same objective, consider Svg with inline sanitized markup. Svg removes external images, scripts, links and foreignObject, so embedding a remote image inside SVG does not bypass the policy. A diagram cannot replace a required photograph or screenshot without revising the learning decision.

Verify loading and legibility in the target MCP host in Read and Present. A valid OUI source or an image that works in Viewer does not prove it loads inside chat. If loading fails, inspect the URL response/redirects, authentication, host CSP and source size; replace the source or revise the composition explicitly. Keep the explanation useful without the image and report an unverified essential image rather than delivering a lesson whose teaching depends on a broken asset. There is no automatic image-failure repair or guaranteed fallback renderer.

## Narration Files

Present is hands-free. Use root = Narration([NarrationStep(beat, caption, effects)]). Effects: Highlight, NarrationCallout, Spotlight. Keep Read and Present content shared and state separate.
