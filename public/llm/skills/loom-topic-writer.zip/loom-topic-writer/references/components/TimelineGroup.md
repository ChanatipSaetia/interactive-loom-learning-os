## Focused component contracts

Page rules: root = Page("Title", body, heading?). One section file is one authored page; choose components, not a section type or library. Use one main visual/activity plus supporting text. Local controls and their visual form one activity. Multiple competing activities produce review warnings, not a component-count rejection. Size the topic to the learner goal. Generic children are alternatives, not mandatory dependencies. Use exact positional signatures; request actual child components and required data models. TextContent handles Markdown prose; Text is a short line or metric. Choose ImageGallery for a preview grid or LearningGallery for captioned learning scenes. All components share one catalog; prebuilt activities are reusable compositions, not a separate authoring mode. Query/Mutation host tools are deferred. Local reactive $variables, input bindings and Set/Reset actions are allowed. Do not use actions unsupported by the host. Use supplied/verified chart data or label illustrative values; never invent benchmarks. Present is hands-free, may use internal scenes/beats, and may render differently from Read using the same content. Demonstrations use authored defaults and never count as learner attempts. Narration is authored in OUI; preserve statement IDs and validate beat/target references. Preview narrow and desktop Read/Present layouts.

## Component Signatures

TimelineGroup(id: string, title: string, activities: (string | TimelineActivity)[], description?: string) — Activities explained together on one presentation beat, including parallel work or a join.
  - id: Group ID, unique within the timeline.
  - title: Short stage name shown in Present.
  - activities: Activities to highlight together, as references or IDs; include parallel activities in one group.
  - description: Optional explanation of what this stage means.
TimelineActivity(id: string, title: string, lane: string | TimelineLane, start: number, duration: number, description?: string, dependsOn?: string[]) — Activity positioned by elapsed start time and duration; zero duration represents a milestone.
  - id: Activity ID, unique within the timeline.
  - title: Short readable activity name.
  - lane: TimelineLane reference or ID.
  - start: Elapsed start time from zero, in the timeline unit.
  - duration: Duration in the same unit; zero is a milestone.
  - description: Optional explanation shown on selection in Read mode.
  - dependsOn: Optional activity IDs that must finish before this activity starts; draws dependency connectors.
TimelineLane(id: string, title: string, color?: "blue" | "teal" | "green" | "mauve" | "peach" | "sky" | "yellow" | "pink" | "lavender") — A named participant or resource used as a task’s secondary label and color. Each task gets its own row.
  - id: Lane ID, unique within the timeline.
  - title: Readable lane name.
  - color: Optional theme accent for the lane and its activities.

### TimelineGroup: teaching purpose

- Introduce: Define the TimelineGroup content or configuration consumed by its owning component.
- Explore: Inspect it through the owning component and its documented behavior.
- Evidence: A supporting data declaration does not independently provide learning evidence.
- Limits: Use the exact required fields and references. This supporting contract does not imply an independently rendered activity, interaction, grading or persistence.

## Narration Files

Present is hands-free. Use root = Narration([NarrationStep(beat, caption, effects)]). Effects: Highlight, NarrationCallout, Spotlight. Keep Read and Present content shared and state separate.
