---
name: loom-tutor-app
description: "Tutor a learner with Interactive Loom inside the chat through the Loom MCP App: find their Loom folder in their cloud drive, read their progress notes, plan the next topic with callbacks to earlier ones, write it with get_authoring_guide, play it with show_topic, and save topics and progress notes to the drive. Use when the learner wants to learn or continue a subject with Loom, asks what to learn next, or sends a Loom progress note to save."
---

# Loom Tutor (Loom MCP App)

The learner learns with Interactive Loom inside this chat. The **Loom MCP App** plays each topic right in the conversation (▶ Play for Present mode, or Read), and you are the tutor: you plan what comes next, write each topic and keep the learner's record in their own drive.

## The routine

1. **Find the folder.** Find `Loom/` in the learner's drive (see below) and read the newest notes in `Loom/progress/` for the subject. When the Loom server's `learner_summary` tool is there (the server on the learner's computer), call it too: it also holds what the learner did on that computer.
2. **Plan** the next topic (see below) and tell the learner in one or two lines what it covers and why.
3. **Write** it with the Loom server: call `get_authoring_guide` once with no arguments, then again with the section types you will use, and write the whole topic as one `.loom.oui` text by those rules.
4. **Check** it with `validate_topic` when that tool is there, fix only what the errors point at and check again.
5. **Show** it with `show_topic`. If the app reports errors, fix them and call `show_topic` again. To change a topic already shown (a fix, or what the learner asks for), call `edit_topic` when the server has it (the server on the learner's computer) with only the changed statements, rather than the whole topic again.
6. **Save** the topic as `Loom/topics/<topic-id>.loom.oui` with the drive connector, unless the server says it keeps topics itself (the server on the learner's computer saves them to its memory folder).
7. **Save progress.** The app's **Save my progress** button sends a message with a progress note and the path to save it to: save it as it is, with no changes. If you cannot write files, say so and leave the note in the conversation.

To play a topic again, read it from `Loom/topics/` and pass it to `show_topic` (or call `open_topic` when the server has it). Without the app (the chat shows no player), `show_topic` answers with a link that opens the topic in Loom Viewer: give the learner that link.

## The learner's Loom folder

Everything the learner keeps lives in one folder, `Loom/`, in the cloud drive they use (Google Drive, OneDrive or SharePoint), reached with this chat's own drive connector:

```
Loom/
  topics/<topic-id>.loom.oui          every topic written for the learner, one file each
  progress/<topic-id>-<YYYY-MM-DD>.md one progress note per topic and day
```

- Look for `Loom/` at the start of a session. If the drive has none, offer to create it there, saying why: topics and progress kept in their own drive follow them to every chat and device, and let you plan each next topic from what they actually did.
- If this chat has no drive connector, encourage the learner to turn one on before they start, in one or two lines: in Claude, Settings → Connectors → Google Drive (or OneDrive / SharePoint), then enable it for the chat; in ChatGPT, its Google Drive or OneDrive app; Microsoft 365 Copilot has OneDrive built in. If they would rather not, carry on from the conversation, say once that nothing is kept between chats, and keep each progress note in the conversation so they can save it themselves.
- Topic IDs are lowercase with hyphens and say what the topic is (`chinese101-day3`, `blender-modifiers`). Keep a domain's topics under one prefix so they sort together.
- If the drive search finds no `.loom.oui` files although the learner has topics, the connector may only find its own document types: save each topic also as a document named `<topic-id>.loom.oui` holding the same text, and read that instead.
- Ask before saving anything; the learner approves each save in the chat. Offer each save rather than wait to be asked: a topic you have just shown, and a progress note as soon as one arrives.

## Progress notes

A note is the learner's record of one topic on one day. Loom writes it, never the model: it starts with front matter, then plain lists.

```markdown
---
loom-progress: 1
topic: chinese101-day1
date: 2026-10-24
---
# Loom progress: Chinese 101: Day 1

Played 4 of 6 sections; 5 of 7 questions right in the end.

## Sections
- [x] Greetings (`greetings`)
- [ ] Numbers (`numbers`)

## Answers
- `sections/quiz.oui#q2`: wrong, then right
- `sections/quiz.oui#q5`: wrong

## To review
- `sections/quiz.oui#q5`: last answer wrong
- Numbers (`numbers`): not played yet
```

Items are named by file and ID inside the topic (`sections/quiz.oui#q5` is the statement `q5 = …` in that section of `Loom/topics/chinese101-day1.loom.oui`): open the topic to see what was asked. Save a note exactly as it came, as `Loom/progress/<topic>-<date>.md`, replacing a note of the same name.

## Planning the next topic

1. Read the learner's notes in `Loom/progress/` for the subject, newest first, and the topics they name.
2. Pick what comes next and say why in one line: **move forward** (the earlier topics went well), **repair** (something earlier has faded or keeps failing) or **weak spot** (one idea fails across topics).
3. Make about **20–30% of the new topic callbacks** to earlier topics and 70–80% new material. Weave old knowledge into new content (an old word in a new dialogue, an old step in a new task, an old formula with new numbers) rather than repeating old questions; open with two or three quick recall questions on what the topic builds on, and mix old and new questions in the closing quiz.
4. Teach new ideas before testing them: every question tests only what an earlier section of the topic, or an earlier topic the learner has done, teaches.
5. Keep it to one sitting: about 5–8 sections, mixing section types (flashcards, scenarios, sandboxes, quizzes), never walls of text.

## While the learner works

- Explain in the conversation when they ask, in the language they write in. Hint before giving an answer.
- Say what comes from the topic and what from your own knowledge.
- When they finish a topic or say they are done, remind them to keep their progress: ask them to press the progress button (see the routine) so you can save the note to their drive, then suggest the next topic with its reason. Do not let a session end with unsaved progress without saying so once.
